package com.minis.dsbalance;

import android.graphics.drawable.GradientDrawable;

/** 双主题色板 + 圆角/圆形背景工厂（暗色优先，AMOLED 省电） */
public class Theme {

    public static final int DARK = 0;
    public static final int LIGHT = 1;

    public static int bg(boolean d)        { return d ? 0xFF000000 : 0xFFF5F5F7; }
    public static int secondary(boolean d) { return d ? 0xFF8A8F98 : 0xFF6B7280; }
    public static int accent(boolean d)    { return d ? 0xFF4ECDA4 : 0xFF0E7C5A; }
    public static int mainText(boolean d)  { return d ? 0xFFECECEC : 0xFF1C1C1E; }
    public static int btnFill(boolean d)   { return d ? 0xFF14201C : 0xFFDCEFE7; }
    public static int cardFill(boolean d)  { return d ? 0xE6000000 : 0xF2FFFFFF; }
    public static int dialogFill(boolean d){ return d ? 0xFF121212 : 0xFFFFFFFF; }
    public static int rowFill(boolean d)   { return d ? 0xFF161616 : 0xFFEAEAEE; }
    public static int rowSel(boolean d)    { return d ? 0xFF1E2C27 : 0xFFD2EDE3; }

    public static GradientDrawable rounded(int fill, int stroke, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(radius);
        g.setColor(fill);
        if (stroke != 0) g.setStroke(1, stroke);
        return g;
    }

    public static GradientDrawable circle(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        if (stroke != 0) g.setStroke(1, stroke);
        return g;
    }
}
