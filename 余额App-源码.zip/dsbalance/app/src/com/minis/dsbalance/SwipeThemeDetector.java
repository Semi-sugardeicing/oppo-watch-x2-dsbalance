package com.minis.dsbalance;

import android.view.MotionEvent;

/**
 * 主题切换手势 —— 只认「从右往左」。
 *
 * 为什么单向就安全（不需要任何起手点判断）：
 *   手指划不出屏幕 → 终点 x 最小为 0 → 起手 x = 终点 x + |dx| ≥ |dx| = 120px。
 *   即：凡是能触发的滑动，起手点必然离左边缘 ≥ 120px，系统返回手势区（约 20~40px）自动被排除。
 *   （右边缘返回已实机验证不存在；万一将来系统改了，预案是改成双击，见 PLAN 第 1 节③。）
 *
 * 本类只"旁听"事件，永远不消费 —— 由 Activity 在 dispatchTouchEvent 里喂给它。
 */
public class SwipeThemeDetector {

    public interface Callback {
        void onRightToLeft();
    }

    private final Callback cb;
    private final float minDx;   // 需要的最小向左位移（px，正数）
    private final float maxDy;   // 允许的最大纵向偏移（px）
    private final float minV;    // 最小速度（px/s）

    private boolean tracking = false;
    private float downX, downY;
    private long downT;

    public SwipeThemeDetector(Callback cb, float minDxPx, float maxDyPx, float minVelPxPerSec) {
        this.cb = cb;
        this.minDx = minDxPx;
        this.maxDy = maxDyPx;
        this.minV = minVelPxPerSec;
    }

    public void onTouch(MotionEvent ev) {
        if (ev == null) return;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = ev.getRawX();
                downY = ev.getRawY();
                downT = ev.getEventTime();
                tracking = true;
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP: {
                if (!tracking) return;
                tracking = false;
                float dx = ev.getRawX() - downX;
                float dy = ev.getRawY() - downY;
                long dt = ev.getEventTime() - downT;
                if (dt <= 0L) dt = 1L;
                double dist = Math.sqrt((double) (dx * dx + dy * dy));
                float vel = (float) (dist * 1000.0d / (double) dt);
                if (dx <= -minDx && Math.abs(dy) <= maxDy && vel >= minV) {
                    cb.onRightToLeft();
                }
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                tracking = false;
                break;
            default:
                break;
        }
    }
}
