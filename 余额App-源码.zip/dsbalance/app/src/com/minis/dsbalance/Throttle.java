package com.minis.dsbalance;

/**
 * 刷新节流（前端防呆刹车）—— 三个阈值集中在这里，实机觉得松/紧直接改这一个文件。
 *
 *  ① 飞行中      ：由界面层的 inFlight 标志处理（本类不重复管）
 *  ② 最小间隔    ：距上次<真实请求> 3 秒 → 拦下，不发请求
 *  ③ 狂点惩罚    ：10 秒窗口内 ≥4 次真实请求 → 进入 10 秒惩罚期（固定，绝不因继续点而延长）
 *
 * 只统计"真实发出的请求"，被拦下的点击不计数。
 */
public class Throttle {

    /** ② 最小请求间隔 */
    public static final long MIN_INTERVAL_MS = 3000L;
    /** ③ 统计窗口 */
    public static final long PUNISH_WINDOW_MS = 10000L;
    /** ③ 窗口内达到该次数即触发惩罚 */
    public static final int  PUNISH_COUNT = 4;
    /** ③ 惩罚时长（固定，不延长） */
    public static final long PUNISH_MS = 10000L;

    public static final int OK = 0;
    /** 距上次请求太近 */
    public static final int TOO_SOON = 1;
    /** 正在惩罚期 */
    public static final int PUNISHED = 2;

    private long lastReqMs = 0L;
    private long windowStartMs = 0L;
    private int  windowCount = 0;
    private long punishUntilMs = 0L;

    /** 请求一次"放行许可"。返回 OK 表示可以发请求；其余值表示被拦下（且不计入统计）。 */
    public int request(long now) {
        if (now < punishUntilMs) return PUNISHED;
        if (lastReqMs > 0L && now - lastReqMs < MIN_INTERVAL_MS) return TOO_SOON;
        if (windowStartMs == 0L || now - windowStartMs > PUNISH_WINDOW_MS) {
            windowStartMs = now;
            windowCount = 0;
        }
        windowCount++;
        lastReqMs = now;
        if (windowCount >= PUNISH_COUNT) {
            punishUntilMs = now + PUNISH_MS;
            windowCount = 0;
            windowStartMs = now;
        }
        return OK;
    }

    /** 惩罚剩余毫秒（0 = 不在惩罚期） */
    public long punishRemain(long now) {
        long r = punishUntilMs - now;
        return r > 0L ? r : 0L;
    }
}
