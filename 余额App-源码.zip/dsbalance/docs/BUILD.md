# 构建说明（无 Gradle）

这个项目**不用 Gradle、不用 Android Studio、没有任何第三方依赖**。
所有视图都在 Java 里手写，`res/` 目录里的资源文件一次都没有被改过 —— 所以**不需要 aapt2 重新编资源**，
只要有一个能打包的 APK 模板 + 一个 `android.jar` + `d8` + `apksigner` 就够了。

## 一条命令

```sh
SDK=/opt/android-sdk sh app/scripts/build.sh          # 产物 app/dist/dsbalance.apk
```

## 需要准备什么

| 变量 | 说明 | 从哪来 |
|---|---|---|
| `SDK` | SDK 根目录（下面几项默认都相对它） | 自己定 |
| `BT` | build-tools 目录，里面要有 `d8`、`apksigner` | Android SDK build-tools 30+ |
| `AJ` | 编译用的 `android.jar`（`-bootclasspath` / `-cp`） | `platforms/android-XX/android.jar` |
| `AJP` | `APKEditor.jar` | <https://github.com/REAndroid/APKEditor/releases> |
| `KS` | 签名密钥库，**不存在时脚本会自动生成一个调试用的** | 自签即可 |

`app/template/` 是打底模板（未打包的 APK 目录：清单 + 资源表 + `path-map.json`）。
`APKEditor b` 会用它把编译出来的 `classes.dex` 重新塞回一个合法 APK 里。

> 模板里刻意**没有**包含 `.cache/` 和 `root/classes.dex` 这两个二进制残留 ——
> 实测去掉之后 `APKEditor b` 依然能正常出包（`classes.dex` 由本项目的编译结果提供）。

## 流程

```
javac -encoding UTF-8          →  build/classes/**.class
d8 --min-api 30                →  build/dex/classes.dex
cp template + classes.dex      →  build/pack/
APKEditor.jar b                →  build/unsigned.apk
apksigner sign                 →  dist/dsbalance.apk
```

打包前脚本会自检**包名三处同步**（`AndroidManifest.xml` / `resources/package_1/package.json` /
`res/values/public.xml`）—— 改包名时这三处必须一起改，否则装不上。

## 换包名

```sh
find app -type f \( -name '*.java' -o -name '*.xml' -o -name '*.json' \) \
  -exec sed -i 's/com\.minis\.dsbalance/你的包名/g' {} +
```
（Java 源码目录 `app/src/com/minis/dsbalance/` 也要跟着移动。）

## 改 App 名

改 `app/template/AndroidManifest.xml` 里的 `android:label`（当前是字面量 `DeepSeek 余额`）。

## 这个构建方式是怎么来的

手表上装不了 Android Studio 那套东西，所以整条链路只依赖四个 CLI 工具。
第一次要打包时用的是别人做好的 APK 模板，改包名后编译产物直接替换 `classes.dex` 即可 —— 
好处是**完全不用碰 `resources.arsc`**，也就不会遇到资源表重建的各种玄学问题。

## 本次发布的产物

```
dist/dsbalance.apk        33820 字节
versionCode / versionName 2 / 1.1
签名                      CN=Minis（作者自用密钥，未随仓库分发）
SHA-256 (APK)             49c538faadb4652811e38ba8a0ef028ab922019540f73d216365e939ea6f9607
系统要求                  Android 11 (API 30) 及以上
```

> ⚠️ **自己构建出来的 APK 签名和上面的不一样。**
> `build.sh` 在找不到密钥时会自动生成一把调试密钥（`CN=dsbalance`），
> 所以源码构建的包**不能覆盖安装**在 `dist/dsbalance.apk` 之上 —— 两者证书不同，
> 想换只能先卸载。同理，`dist/` 里这份也不能覆盖你自己构建的包。
